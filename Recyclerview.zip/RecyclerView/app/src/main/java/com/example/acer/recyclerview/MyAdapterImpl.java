package com.example.acer.recyclerview;

class MyAdapterImpl extends MyAdapter {
}
