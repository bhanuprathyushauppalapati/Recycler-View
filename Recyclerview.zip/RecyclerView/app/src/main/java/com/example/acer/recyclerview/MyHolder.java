package com.example.acer.recyclerview;

class MyHolder extends MyAdapter{
}
